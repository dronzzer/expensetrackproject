from django.shortcuts import render, redirect, get_object_or_404
from .models import Expense
from .forms import ExpenseForm
from django.contrib.auth.decorators import login_required
from django.db.models import Sum

@login_required
def add_expense_view(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            return redirect('list_expenses')
    else:
        form = ExpenseForm()
    return render(request, 'expenses/add_expense.html', {'form': form})

@login_required
def list_expenses_view(request):
    expenses = Expense.objects.filter(user=request.user)
    return render(request, 'expenses/list_expenses.html', {'expenses': expenses})

@login_required
def edit_expense_view(request, pk):
    expense = Expense.objects.get(pk=pk, user=request.user)
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            return redirect('list_expenses')
    else:
        form = ExpenseForm(instance=expense)
    return render(request, 'expenses/edit_expense.html', {'form': form})


@login_required
def expense_summary_view(request):
    total_expenses = Expense.objects.filter(user=request.user).aggregate(Sum('amount'))['amount__sum'] or 0
    expenses_by_category = Expense.objects.filter(user=request.user).values('category').annotate(total=Sum('amount'))

    return render(request, 'expenses/summary.html', {
        'total_expenses': total_expenses,
        'expenses_by_category': expenses_by_category,
    })





@login_required
def delete_expense_view(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)

    if request.method == 'POST':
        expense.delete()
        return redirect('list_expenses')  # Redirect to the list of expenses after deletion
