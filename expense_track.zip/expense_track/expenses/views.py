from django.shortcuts import render, redirect, get_object_or_404
from .models import Expense
from django.utils import timezone
from datetime import timedelta
from .forms import ExpenseForm
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
import csv
from django.http import HttpResponse
@login_required
def add_expense_view(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            return redirect('list_expenses')
    else:
        form = ExpenseForm()
    return render(request, 'expenses/add_expense.html', {'form': form})


@login_required
def list_expenses_view(request):
    # Fetch all expenses for the logged-in user
    expenses = Expense.objects.filter(user=request.user)

    # Get filtering parameters from the GET request
    category = request.GET.get('category')
    amount = request.GET.get('amount')

    # Apply category filtering if a category is selected
    if category and category != '':
        expenses = expenses.filter(category=category)

    # Apply amount filtering if an amount is provided
    if amount and amount != '':
        try:
            # Convert amount to float and filter by greater or equal
            amount = float(amount)
            expenses = expenses.filter(amount__gte=amount)
        except ValueError:
            # Handle cases where the amount is not a valid number (optional)
            pass

    # Get unique categories from the database for the filter dropdown
    categories = dict(Expense.CATEGORY_CHOICES)

    context = {
        'expenses': expenses,
        'categories': categories.keys(),  # Pass the categories to the template
    }

    return render(request, 'expenses/list_expenses.html', context)


@login_required
def edit_expense_view(request, pk):
    expense = Expense.objects.get(pk=pk, user=request.user)
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            return redirect('list_expenses')
    else:
        form = ExpenseForm(instance=expense)
    return render(request, 'expenses/edit_expense.html', {'form': form})


@login_required
def expense_summary_view(request):
    # Get the current date
    today = timezone.now().date()

    # Calculate dates for weekly and monthly summaries
    one_week_ago = today - timedelta(days=7)
    one_month_ago = today - timedelta(days=30)

    # Filter expenses for weekly and monthly
    weekly_expenses = Expense.objects.filter(date__gte=one_week_ago, user=request.user)
    monthly_expenses = Expense.objects.filter(date__gte=one_month_ago, user=request.user)

    context = {
        'weekly_expenses': weekly_expenses,
        'monthly_expenses': monthly_expenses,
    }

    return render(request, 'expenses/summary.html', context)  # Fixed the template path


@login_required
def delete_expense_view(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)

    if request.method == 'POST':
        expense.delete()
        return redirect('list_expenses')  # Redirect to the list of expenses after deletion


@login_required
def export_expenses_csv_view(request):
    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="expenses.csv"'

    # Create a CSV writer object
    writer = csv.writer(response)

    # Write the header row for the CSV file
    writer.writerow(['Date', 'Category', 'Amount', 'Description'])

    # Query to get all expenses of the logged-in user
    expenses = Expense.objects.filter(user=request.user)

    # Write expense data rows to the CSV file
    for expense in expenses:
        writer.writerow([expense.date, expense.category, expense.amount, expense.description])

    return response