# expenses/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('add/', views.add_expense_view, name='add_expense'),
    path('', views.list_expenses_view, name='list_expenses'),
    path('edit/<int:pk>/', views.edit_expense_view, name='edit_expense'),
    path('delete/<int:pk>/', views.delete_expense_view, name='delete_expense'),
    path('summary/', views.expense_summary_view, name='expense_summary'),
    path('expenses/summary/', views.expense_summary_view, name='expense_summary'),
    path('expenses/export-csv/', views.export_expenses_csv_view, name='export_expenses_csv'),
]
